import "./App.css";
import WebSocketComponent from "./WebSocketMy";

function App() {
  return (
    <>
      <WebSocketComponent />
    </>
  );
}

export default App;
